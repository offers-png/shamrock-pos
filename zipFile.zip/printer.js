let escpos, USB;

try {
  escpos = require('escpos');
  USB = require('escpos-usb');
  escpos.USB = USB;
} catch (e) {
  console.warn('ESC/POS printer modules not available, printing will be skipped.');
}

function printReceipt(payload) {
  return new Promise((resolve, reject) => {
    if (!escpos || !USB) {
      console.log('printReceipt called, but ESC/POS modules not installed. Skipping.');
      return resolve();
    }

    try {
      const device = new escpos.USB();
      device.open((error) => {
        if (error) return reject(error);

        const printer = new escpos.Printer(device, { width: 48, encoding: 'CP437' });
        const {
          store, items, subtotal, discount,
          taxRate, taxAmount, total, paymentType, openDrawer
        } = payload || {};

        const fmt = (n) => Number(n || 0).toFixed(2);

        printer
          .align('ct')
          .style('b')
          .text(store?.name || 'Shamrock Market')
          .style('normal');

        if (store?.phone) printer.text(store.phone);

        printer.text('--------------------------------');

        if (paymentType) {
          printer.text(`Payment: ${paymentType}`);
          printer.text('--------------------------------');
        }

        if (Array.isArray(items)) {
          items.forEach((item) => {
            const name = String(item.name || '').slice(0, 20);
            const qty = item.qty || 1;
            const price = fmt(item.price);
            const lineTotal = fmt(item.total || qty * (item.price || 0));

            printer.text(name);
            printer.text(`  ${qty} x $${price}   ....   $${lineTotal}`);
          });
        }

        printer.text('--------------------------------');
        printer.text(`Subtotal: $${fmt(subtotal)}`);
        if (discount) printer.text(`Discount: -$${fmt(discount)}`);
        if (taxAmount) printer.text(`Tax (${taxRate || 0}%): $${fmt(taxAmount)}`);
        printer.text(`TOTAL:   $${fmt(total)}`);
        printer.text('--------------------------------');
        printer.text('Thank you for shopping!');
        printer.feed(3);
        printer.cut();

        if (openDrawer) {
          printer.cashdraw();
        }

        printer.close();
        resolve();
      });
    } catch (err) {
      reject(err);
    }
  });
}

module.exports = { printReceipt };
