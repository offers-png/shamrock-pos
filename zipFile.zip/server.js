import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { execSync } from "child_process";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

app.use(express.json());

app.use((req, res, next) => {
  res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
  next();
});

app.use(express.static(__dirname));

// ---------- LOCAL FILE PATHS (BACKUP ONLY) ----------
const productsFile = path.join(__dirname, "products.json");
const salesFile = path.join(__dirname, "sales.json");

// ---------- Google Sheets (PRIMARY STORAGE) ----------
let sheetsClient = null;
let googleEnabled = false;
const PRODUCTS_SHEET_ID = "12muhfAiyuoywVpxUI3zHzTWIu1wk5-IGYTvFEKopkvk";
const SALES_SHEET_ID = "16vFYJ1uSeiNvsFJ79ViyMfmtwH964czwNflUG1ZxQnI";

async function initGoogleSheets() {
  try {
    const credPath = path.join(__dirname, "shamrock-pos-credentials.json");
    if (!fs.existsSync(credPath)) {
      console.log("Google credentials not found - running in OFFLINE mode");
      return;
    }
    
    const { google } = await import("googleapis");
    const auth = new google.auth.GoogleAuth({
      keyFile: credPath,
      scopes: ["https://www.googleapis.com/auth/spreadsheets"],
    });
    const authClient = await auth.getClient();
    sheetsClient = google.sheets({ version: "v4", auth: authClient });
    googleEnabled = true;
    console.log("Google Sheets connected - products will be saved to Google Sheets!");
  } catch (err) {
    console.log("Google Sheets unavailable - running in OFFLINE mode:", err.message);
    googleEnabled = false;
  }
}

// ---------- GOOGLE SHEETS PRODUCT FUNCTIONS (PRIMARY) ----------
async function loadProductsFromSheets() {
  if (!googleEnabled || !sheetsClient) return null;
  try {
    const res = await sheetsClient.spreadsheets.values.get({
      spreadsheetId: PRODUCTS_SHEET_ID,
      range: "Sheet1!A:D",
    });
    const rows = res.data.values || [];
    if (rows.length <= 1) return []; // header only or empty
    
    const dataRows = rows.slice(1);
    return dataRows.map((r) => ({
      barcode: r[0] || "",
      name: r[1] || "",
      price: parseFloat(r[2] || "0") || 0,
      category: r[3] || "Other / Misc",
    }));
  } catch (e) {
    console.log("Error loading from Google Sheets:", e.message);
    return null;
  }
}

async function saveProductToSheets(product) {
  if (!googleEnabled || !sheetsClient) return false;
  try {
    const res = await sheetsClient.spreadsheets.values.get({
      spreadsheetId: PRODUCTS_SHEET_ID,
      range: "Sheet1!A:D",
    });
    const rows = res.data.values || [];
    const header = rows.length > 0 ? rows[0] : ["barcode", "name", "price", "category"];
    const dataRows = rows.length > 1 ? rows.slice(1) : [];
    
    let updated = false;
    const newRows = dataRows.map((r) => {
      if (r[0] === product.barcode) {
        updated = true;
        return [product.barcode, product.name, product.price, product.category || "Other / Misc"];
      }
      return r;
    });
    
    if (!updated) {
      newRows.push([product.barcode, product.name, product.price, product.category || "Other / Misc"]);
    }
    
    const values = [header, ...newRows];
    await sheetsClient.spreadsheets.values.clear({
      spreadsheetId: PRODUCTS_SHEET_ID,
      range: "Sheet1",
    });
    await sheetsClient.spreadsheets.values.update({
      spreadsheetId: PRODUCTS_SHEET_ID,
      range: "Sheet1!A1:D",
      valueInputOption: "USER_ENTERED",
      resource: { values },
    });
    console.log("Product saved to Google Sheets:", product.name);
    return true;
  } catch (e) {
    console.log("Failed to save to Google Sheets:", e.message);
    return false;
  }
}

async function deleteProductFromSheets(barcode) {
  if (!googleEnabled || !sheetsClient) return false;
  try {
    const res = await sheetsClient.spreadsheets.values.get({
      spreadsheetId: PRODUCTS_SHEET_ID,
      range: "Sheet1!A:D",
    });
    const rows = res.data.values || [];
    if (rows.length <= 1) return true;
    
    const header = rows[0];
    const dataRows = rows.slice(1);
    const filtered = dataRows.filter((r) => r[0] !== barcode);
    
    const values = [header, ...filtered];
    await sheetsClient.spreadsheets.values.clear({
      spreadsheetId: PRODUCTS_SHEET_ID,
      range: "Sheet1",
    });
    await sheetsClient.spreadsheets.values.update({
      spreadsheetId: PRODUCTS_SHEET_ID,
      range: "Sheet1!A1:D",
      valueInputOption: "USER_ENTERED",
      resource: { values },
    });
    return true;
  } catch (e) {
    console.log("Failed to delete from Google Sheets:", e.message);
    return false;
  }
}

async function saveSaleToSheets(sale) {
  if (!googleEnabled || !sheetsClient) return false;
  try {
    const values = [[
      sale.timestamp,
      sale.saleId || "",
      sale.paymentType || "",
      sale.subtotal || 0,
      sale.discount || 0,
      sale.tax || 0,
      sale.total || 0,
      sale.itemCount || 0,
    ]];
    await sheetsClient.spreadsheets.values.append({
      spreadsheetId: SALES_SHEET_ID,
      range: "Sheet1!A:H",
      valueInputOption: "USER_ENTERED",
      resource: { values },
    });
    console.log("Sale logged to Google Sheets");
    return true;
  } catch (e) {
    console.log("Failed to save sale to Google Sheets:", e.message);
    return false;
  }
}

async function getTodaySalesFromSheets() {
  if (!googleEnabled || !sheetsClient) return null;
  try {
    const res = await sheetsClient.spreadsheets.values.get({
      spreadsheetId: SALES_SHEET_ID,
      range: "Sheet1!A:H",
    });
    const rows = res.data.values || [];
    if (rows.length <= 1) return [];
    return rows.slice(1);
  } catch (e) {
    console.log("Failed to load sales from Google Sheets:", e.message);
    return null;
  }
}

// ---------- LOCAL STORAGE HELPERS (BACKUP) ----------
function loadLocalProducts() {
  try {
    if (fs.existsSync(productsFile)) {
      const data = fs.readFileSync(productsFile, "utf-8");
      const parsed = JSON.parse(data);
      return Array.isArray(parsed) ? parsed : [];
    }
  } catch (e) {
    console.error("Error reading products.json:", e.message);
  }
  return [];
}

function saveLocalProducts(products) {
  try {
    fs.writeFileSync(productsFile, JSON.stringify(products, null, 2), "utf-8");
    return true;
  } catch (e) {
    console.error("Error saving products.json:", e.message);
    return false;
  }
}

function loadLocalSales() {
  try {
    if (fs.existsSync(salesFile)) {
      const data = fs.readFileSync(salesFile, "utf-8");
      const parsed = JSON.parse(data);
      return Array.isArray(parsed) ? parsed : [];
    }
  } catch (e) {
    console.error("Error reading sales.json:", e.message);
  }
  return [];
}

function saveLocalSales(sales) {
  try {
    fs.writeFileSync(salesFile, JSON.stringify(sales, null, 2), "utf-8");
    return true;
  } catch (e) {
    console.error("Error saving sales.json:", e.message);
    return false;
  }
}

// ---------- API ROUTES ----------

// Get all products (GOOGLE SHEETS FIRST, fallback to local)
app.get("/api/products", async (req, res) => {
  let products = await loadProductsFromSheets();
  if (products === null) {
    // Fallback to local
    products = loadLocalProducts();
    return res.json({ success: true, products, source: "local", offline: true });
  }
  // Also save to local as backup
  saveLocalProducts(products);
  res.json({ success: true, products, source: "google_sheets", offline: false });
});

// Add or update product (GOOGLE SHEETS FIRST)
app.post("/api/products", async (req, res) => {
  const { barcode, name, price, category } = req.body || {};
  if (!barcode || !name || typeof price !== "number") {
    return res.status(400).json({ success: false, error: "Invalid product data" });
  }
  
  const product = { barcode, name, price, category: category || "Other / Misc" };
  
  if (googleEnabled) {
    const saved = await saveProductToSheets(product);
    if (saved) {
      // Also update local backup
      const products = loadLocalProducts();
      const idx = products.findIndex((p) => p.barcode === barcode);
      if (idx >= 0) {
        products[idx] = product;
      } else {
        products.push(product);
      }
      saveLocalProducts(products);
      return res.json({ success: true, saved_to: "google_sheets" });
    }
  }
  
  // Fallback to local only
  const products = loadLocalProducts();
  const idx = products.findIndex((p) => p.barcode === barcode);
  if (idx >= 0) {
    products[idx] = product;
  } else {
    products.push(product);
  }
  
  if (saveLocalProducts(products)) {
    res.json({ success: true, saved_to: "local_only", offline: true });
  } else {
    res.status(500).json({ success: false, error: "Failed to save product" });
  }
});

// Update product by barcode
app.put("/api/products/:barcode", async (req, res) => {
  const { barcode } = req.params;
  const { name, price, category } = req.body || {};
  if (!barcode || !name || typeof price !== "number") {
    return res.status(400).json({ success: false, error: "Invalid product data" });
  }
  
  const product = { barcode, name, price, category: category || "Other / Misc" };
  
  if (googleEnabled) {
    const saved = await saveProductToSheets(product);
    if (saved) {
      const products = loadLocalProducts();
      const idx = products.findIndex((p) => p.barcode === barcode);
      if (idx >= 0) {
        products[idx] = product;
      } else {
        products.push(product);
      }
      saveLocalProducts(products);
      return res.json({ success: true, saved_to: "google_sheets" });
    }
  }
  
  // Fallback to local
  const products = loadLocalProducts();
  const idx = products.findIndex((p) => p.barcode === barcode);
  if (idx >= 0) {
    products[idx] = product;
  } else {
    products.push(product);
  }
  
  if (saveLocalProducts(products)) {
    res.json({ success: true, saved_to: "local_only", offline: true });
  } else {
    res.status(500).json({ success: false, error: "Failed to save product" });
  }
});

// Delete product by barcode
app.delete("/api/products/:barcode", async (req, res) => {
  const { barcode } = req.params;
  if (!barcode) {
    return res.status(400).json({ success: false, error: "Missing barcode" });
  }
  
  let deletedFromSheets = false;
  if (googleEnabled) {
    deletedFromSheets = await deleteProductFromSheets(barcode);
    if (!deletedFromSheets) {
      return res.status(500).json({ 
        success: false, 
        error: "Failed to delete from Google Sheets. Product NOT deleted.",
        offline: true 
      });
    }
  }
  
  // Also delete from local backup
  let products = loadLocalProducts();
  products = products.filter((p) => p.barcode !== barcode);
  saveLocalProducts(products);
  
  res.json({ 
    success: true, 
    deleted_from: googleEnabled ? "google_sheets" : "local_only",
    offline: !googleEnabled 
  });
});

// Log a sale (GOOGLE SHEETS FIRST)
app.post("/api/sales", async (req, res) => {
  const { items, paymentType, subtotal, discount, tax, total } = req.body || {};
  const saleId = Date.now().toString();
  const timestamp = new Date().toISOString();
  const itemCount = Array.isArray(items) ? items.reduce((sum, it) => sum + (it.qty || 1), 0) : 0;
  
  const sale = { timestamp, saleId, paymentType, subtotal, discount, tax, total, itemCount, items };
  
  let savedToSheets = false;
  if (googleEnabled) {
    savedToSheets = await saveSaleToSheets(sale);
  }
  
  // Also save locally as backup
  const sales = loadLocalSales();
  sales.push(sale);
  saveLocalSales(sales);
  
  res.json({ 
    success: true, 
    saleId, 
    saved_to: savedToSheets ? "google_sheets" : "local_only",
    offline: !savedToSheets
  });
});

// Get today's end-of-day summary
app.get("/api/eod-today", async (req, res) => {
  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);
  
  const totals = { Cash: 0, "Debit Card": 0, EBT: 0, "Store Credit": 0 };
  const counts = { Cash: 0, "Debit Card": 0, EBT: 0, "Store Credit": 0 };
  let grandTotal = 0;
  let transactionCount = 0;
  
  // Try Google Sheets first
  let salesRows = await getTodaySalesFromSheets();
  
  if (salesRows !== null) {
    for (const r of salesRows) {
      const ts = r[0] || "";
      if (!ts.startsWith(todayStr)) continue;
      const paymentType = r[2] || "";
      const saleTotal = parseFloat(r[6] || "0") || 0;
      grandTotal += saleTotal;
      transactionCount += 1;
      if (totals[paymentType] !== undefined) {
        totals[paymentType] += saleTotal;
        counts[paymentType] += 1;
      }
    }
  } else {
    // Fallback to local
    const sales = loadLocalSales();
    for (const sale of sales) {
      if (!sale.timestamp || !sale.timestamp.startsWith(todayStr)) continue;
      grandTotal += sale.total || 0;
      transactionCount += 1;
      const pt = sale.paymentType || "";
      if (totals[pt] !== undefined) {
        totals[pt] += sale.total || 0;
        counts[pt] += 1;
      }
    }
  }
  
  res.json({ success: true, totals, counts, grandTotal, transactionCount, offline: !googleEnabled });
});

// Status check
app.get("/api/status", async (req, res) => {
  let sheetsProductCount = 0;
  if (googleEnabled) {
    const products = await loadProductsFromSheets();
    sheetsProductCount = products ? products.length : 0;
  }
  
  res.json({
    success: true,
    googleEnabled,
    mode: googleEnabled ? "Google Sheets (online)" : "Local files (offline)",
    sheetsProductCount,
    localProductCount: loadLocalProducts().length,
    localSalesCount: loadLocalSales().length,
  });
});

// Create download ZIP
function createDownloadZip() {
  try {
    const files = [
      'index.html',
      'server.js',
      'smartmartloginpage.html',
      'products.json',
      'sales.json',
      'package.json',
      'download.html',
      'shamrock-pos-credentials.json'
    ].filter(f => fs.existsSync(path.join(__dirname, f)));
    
    if (files.length > 0) {
      const fileList = files.join(' ');
      execSync(`zip -r shamrock_pos_project.zip ${fileList}`, { cwd: __dirname, stdio: 'pipe' });
      console.log("Download ZIP created: shamrock_pos_project.zip");
    }
  } catch (err) {
    console.log("Could not create ZIP:", err.message);
  }
}

// Serve login page as default
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "login.html"));
});

// Initialize
async function start() {
  await initGoogleSheets();
  
  // Ensure sales.json exists
  if (!fs.existsSync(salesFile)) {
    fs.writeFileSync(salesFile, "[]", "utf-8");
  }
  
  // If Google is enabled, load products from Sheets to local as backup
  if (googleEnabled) {
    const sheetProducts = await loadProductsFromSheets();
    if (sheetProducts && sheetProducts.length > 0) {
      saveLocalProducts(sheetProducts);
      console.log(`Synced ${sheetProducts.length} products from Google Sheets to local backup`);
    }
  }
  
  createDownloadZip();
  
  const PORT = 5000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Shamrock POS running on http://localhost:${PORT}`);
    console.log(`Storage: ${googleEnabled ? "GOOGLE SHEETS (primary)" : "LOCAL FILES (offline)"}`);
    console.log("Download page: /download.html");
  });
}

start();
